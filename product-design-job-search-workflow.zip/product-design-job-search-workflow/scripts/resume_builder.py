#!/usr/bin/env python3
"""
Resume PDF generator. Edit content.json, never the layout.

Usage:
    python3 resume_builder.py content.json out.pdf [max_pages]

Prints OK or a list of issues. Requires reportlab and poppler-utils (pdfinfo,
pdftotext). Inter downloads once to ~/.cache/inter-ttf; Helvetica if offline.
"""

import json
import os
import re
import subprocess
import sys
import urllib.request
import zipfile

from reportlab.lib.colors import HexColor
from reportlab.lib.pagesizes import A4, letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import (BaseDocTemplate, Frame, KeepTogether,
                                PageTemplate, Paragraph, Spacer)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

FONT_CACHE = os.path.expanduser("~/.cache/inter-ttf")
INTER_URL = "https://github.com/rsms/inter/releases/download/v4.1/Inter-4.1.zip"
FALLBACK = {"regular": "Helvetica", "semibold": "Helvetica-Bold",
            "bold": "Helvetica-Bold"}


def ensure_font():
    ttf_dir = os.path.join(FONT_CACHE, "extras", "ttf")
    if not os.path.isdir(ttf_dir):
        try:
            os.makedirs(FONT_CACHE, exist_ok=True)
            zpath = os.path.join(FONT_CACHE, "inter.zip")
            urllib.request.urlretrieve(INTER_URL, zpath)
            with zipfile.ZipFile(zpath) as z:
                z.extractall(FONT_CACHE)
            os.remove(zpath)
        except Exception as e:  # noqa: BLE001
            print(f"[warn] Inter unavailable ({e}); using Helvetica", file=sys.stderr)
            return FALLBACK
    try:
        for name, fn in {"Inter": "Inter-Regular.ttf",
                         "Inter-SemiBold": "Inter-SemiBold.ttf",
                         "Inter-Bold": "Inter-Bold.ttf"}.items():
            pdfmetrics.registerFont(TTFont(name, os.path.join(ttf_dir, fn)))
    except Exception as e:  # noqa: BLE001
        print(f"[warn] Inter failed to load ({e}); using Helvetica", file=sys.stderr)
        return FALLBACK
    return {"regular": "Inter", "semibold": "Inter-SemiBold", "bold": "Inter-Bold"}


MARGIN, TOP, BOTTOM = 44.64, 42.0, 36.0   # 0.62in sides
INK, MUTED = HexColor("#111111"), HexColor("#444444")


def styles(F, scale=1.0, gap=1.0):
    body, lead = 9.0 * scale, 11.7 * scale

    def s(name, font, size, leading, color=INK, **kw):
        return ParagraphStyle(name, fontName=F[font], fontSize=size,
                              leading=leading, textColor=color, **kw)
    return {
        "name": s("name", "bold", 19, 21, spaceAfter=2.5),
        "title": s("title", "semibold", 10.5, 13, spaceAfter=3.5),
        "contact": s("contact", "regular", 8.5, 11, MUTED, spaceAfter=9 * gap),
        "summary": s("summary", "regular", body, lead, spaceAfter=12 * gap),
        "section": s("section", "bold", 10.5, 13, spaceAfter=5 * gap),
        "role": s("role", "semibold", 10, 12.5, spaceAfter=1.5),
        "meta": s("meta", "regular", 8.5, 11, MUTED, spaceAfter=3.5 * gap),
        "bullet": s("bullet", "regular", body, lead, leftIndent=9.5,
                    bulletIndent=0, spaceAfter=3.6 * scale * gap),
        "line": s("line", "regular", body, lead, spaceAfter=2.5 * gap),
    }


def story(c, S, F, gap):
    # Non-breaking space inside each contact item so "City, ST" never splits.
    contact = " · ".join(x.replace(" ", " ") for x in c.get("contact", []))
    st = [Paragraph(c["name"], S["name"]), Paragraph(c["title"], S["title"]),
          Paragraph(contact, S["contact"])]
    if c.get("summary"):
        st.append(Paragraph(c["summary"], S["summary"]))

    st.append(Paragraph("Experience", S["section"]))
    for job in c["experience"]:
        head = [Paragraph(f"{job['role']} · {job['company']}", S["role"]),
                Paragraph(" · ".join(job.get("meta", [])), S["meta"])]
        bullets = job.get("bullets", [])
        if bullets:
            head.append(Paragraph(bullets[0], S["bullet"], bulletText="•"))
        st.append(KeepTogether(head))  # role header never orphans
        st += [Paragraph(b, S["bullet"], bulletText="•") for b in bullets[1:]]
        st.append(Spacer(1, 7 * gap))

    for label, key in (("Education", "education"),):
        if c.get(key):
            st += [Spacer(1, 3 * gap), Paragraph(label, S["section"])]
            st += [Paragraph(e, S["line"]) for e in c[key]]
    for sec in c.get("extra_sections", []):  # {"heading": "...", "lines": [...]}
        st += [Spacer(1, 10 * gap), Paragraph(sec["heading"], S["section"])]
        st += [Paragraph(x, S["line"]) for x in sec["lines"]]
    if c.get("skills"):
        st += [Spacer(1, 10 * gap), Paragraph("Skills", S["section"])]
        st += [Paragraph(f"<font name='{F['semibold']}'>{cat}:</font> {items}",
                         S["line"]) for cat, items in c["skills"]]
    return st


def render(c, out, scale=1.0, gap=1.0):
    F = ensure_font()
    size = A4 if c.get("page_size") == "A4" else letter
    doc = BaseDocTemplate(out, pagesize=size, leftMargin=MARGIN,
                          rightMargin=MARGIN, topMargin=TOP, bottomMargin=BOTTOM,
                          title=c.get("pdf_title", f"{c['name']} Resume"),
                          author=c["name"])
    frame = Frame(doc.leftMargin, doc.bottomMargin, doc.width, doc.height,
                  leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0)
    doc.addPageTemplates([PageTemplate(id="body", frames=[frame])])
    doc.build(story(c, styles(F, scale, gap), F, gap))


def pages(path):
    out = subprocess.run(["pdfinfo", path], capture_output=True, text=True).stdout
    m = re.search(r"^Pages:\s+(\d+)", out, re.M)
    return int(m.group(1)) if m else -1


def build(c, out, max_pages=1):
    """Fit to max_pages: compress spacing first, shrink type last."""
    if max_pages > 1:
        for gap in (1.6, 1.45, 1.3, 1.15, 1.0):  # fill the last page evenly
            render(c, out, 1.0, gap)
            if pages(out) <= max_pages:
                return
    ladder = [(1.0, 1.0), (1.0, 0.85), (1.0, 0.72), (1.0, 0.6),
              (0.98, 0.6), (0.96, 0.6), (0.94, 0.55), (0.92, 0.5)]
    for scale, gap in ladder:
        render(c, out, scale, gap)
        if pages(out) <= max_pages:
            if (scale, gap) != (1.0, 1.0):
                print(f"[info] fit at type {scale}, spacing {gap}", file=sys.stderr)
            return
    order = c.get("rules", {}).get("trim_order", "Skills, oldest role, low-signal lines")
    print(f"[warn] over {max_pages}p at min density. Trim: {order}", file=sys.stderr)


def validate(c, pdf, max_pages=1):
    rules = c.get("rules", {})
    txt = subprocess.run(["pdftotext", "-layout", pdf, "-"],
                         capture_output=True, text=True).stdout
    flat = " ".join(txt.split())
    issues = []
    n = pages(pdf)
    if n > max_pages:
        issues.append(f"{n} pages (max {max_pages})")
    if not flat.strip():
        issues.append("empty text layer (ATS cannot read it)")
    for ch in rules.get("banned_chars", ["—"]):
        if ch in txt:
            issues.append(f"banned character {ch!r}")
    if rules.get("curly_quotes"):
        for ch, label in (("'", "straight apostrophe"), ('"', "straight quote")):
            if ch in txt:
                issues.append(label)
    for p in rules.get("banned_phrases", []):
        if re.search(p, flat, re.I):
            issues.append(f"banned phrase: {p}")
    return issues


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    with open(sys.argv[1], encoding="utf-8") as f:
        content = json.load(f)
    mp = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    build(content, sys.argv[2], mp)
    problems = validate(content, sys.argv[2], mp)
    print("OK" if not problems else "ISSUES: " + "; ".join(problems))
