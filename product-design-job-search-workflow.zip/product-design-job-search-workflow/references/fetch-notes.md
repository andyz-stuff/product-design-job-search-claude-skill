# Fetch notes

How job boards behave when fetched. Saves failed fetches and repeat requests for pasted text.

## Usually fetch cleanly

- Greenhouse (`job-boards.greenhouse.io`, `boards.greenhouse.io`). Occasional bot check: retry once, then ask for the paste.
- Lever
- SmartRecruiters
- Rippling ATS

## JS-walled: ask for the pasted JD

- Workday (`*.myworkdayjobs.com`)
- Ashby posting pages (`jobs.ashbyhq.com`)
- `workatastartup.com` (returns 406)
- Most large companies' own careers sites (an ATS inside a JS shell)

## Workarounds

- **Ashby:** `api.ashbyhq.com/posting-api/job-board/[company-slug]?includeCompensation=true` returns full JD text and bands for every open req. Slug comes from the posting URL. Sometimes also blocked.
- **Walled big-company pages:** web search the job ID for the qualifications text; a sibling req on the same team often shows the band.
- **404 on a live req:** use search snippets, or ask for the paste.

## Cautions

- The public band is sometimes narrower than the one a candidate receives. Treat it as an estimate.
- If the user says a "not found" posting is live, believe them and ask for the text.
- Check the posting date. A req open for months is a pipeline posting or a hard-to-fill role; both change the odds.

## Asking for a paste

Ask once. Name the board, and ask for the full posting including the comp section and qualifications. A partial paste means screening twice.
