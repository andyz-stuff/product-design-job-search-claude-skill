# Fetch notes

How job boards behave when fetched. Saves a round of failed fetches and an unnecessary "can you paste it" every time.

## Usually fetch cleanly

- Greenhouse (`job-boards.greenhouse.io`)
- Lever
- SmartRecruiters
- Rippling ATS
- Amazon's own careers site

Greenhouse occasionally serves bot detection. Retry once, then ask for pasted text.

## JavaScript-walled, ask for the pasted JD

- Workday boards (`*.myworkdayjobs.com`)
- Ashby posting pages (`jobs.ashbyhq.com`)
- Most large enterprises' own careers pages, which wrap an ATS in a JS shell

## Board-specific workarounds

- **Ashby:** the posting page is walled, but `api.ashbyhq.com/posting-api/job-board/[company]` returns board-level data including full JD text for every open req. Take the company slug from the posting URL.
- **Apple:** job detail pages are walled. Fetch a sibling requisition on the same team for the comp band, and use web search with the job ID to surface the qualifications text.
- **ServiceNow:** careers URLs often 404 on direct fetch. Use search result snippets or ask for the pasted posting.
- **`workatastartup.com`:** returns 406. Always ask for pasted text.

## General cautions

- A public posting sometimes shows a narrower comp band than the JD a candidate receives directly. Treat the public band as a floor estimate.
- Some boards return "no job found" for a live requisition. If the user says it is live, believe them and ask for the text.
- Check the posting date. A req open for months is either a pipeline posting or a role nobody can fill, and both change the odds.

## When asking for pasted text

Ask once, name the board and why, and ask for the whole posting including the comp section and the qualifications list. A partial paste means running the screen twice.
