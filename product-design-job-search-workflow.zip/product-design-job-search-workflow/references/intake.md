# Intake

Goal: a usable profile in about 10 minutes. Gaps get filled the first time they matter.

## Rules

- **Draft first.** Ask for a resume, LinkedIn URL, or portfolio. Draft level, years, domains, employer sizes, and standing bullets from it. The user corrects the draft.
- **Batch questions.** Four rounds, several questions each. Never one at a time.
- **Push back once on vague answers** ("flexible on comp", "anywhere in the metro"). Offer a concrete reframe. If still vague, record it as vague; the screen will flag that step as soft.
- **Never ask what the resume answers.**

## Round 1: Level and target

- Current and target level. If different, the case for the jump.
- IC only, or open to management.
- Employed, or searching after a layoff or departure. Timeline.
- Work authorization constraints that affect which employers can hire them (e.g. needs sponsorship, or TN/Canadian status). Record only what the screen needs: "needs sponsorship: yes/no".

## Round 2: Hard gates

- **Base comp floor.** One number, in USD or CAD. If they have none, derive it: current base, the number they would decline on a bad day, market data for level and metro. Posted bands in CA, CO, NY, WA, BC, and ON are a good market source.
- **Geography.** Three lists: yes, conditional (on what), no. A metro is not one place for commute purposes; get specific cities or regions.
- **Days-in-office ceiling.** A number.
- **Relocation.** Yes, no, or for what.

## Round 3: Dealbreakers

People do not generate exclusions cold. Read this menu and let them react:

- Responsibilities: managing people, shipping production code, on-call, sales calls, sole designer
- Disciplines: growth and conversion, engagement mechanics, data viz and BI, geospatial, game UI, brand and marketing, design systems as the whole job
- Industries: defense, crypto, gambling, adtech, tobacco or vice, others
- Company shapes: early-stage with no named investors or customers, no equity, agencies, staffing firms
- Posting signals: years asked above a threshold, unpaid design exercises, no posted band
- Named companies or teams, with reason (an insider warning counts)

## Round 4: Domain, materials, voice

- The shape of work they want (operational systems, consumer scale, developer tools, marketplaces, etc.), not only industry.
- Domains with recent evidence vs. evidence only in older work (the second list becomes soft flags).
- Portfolio URL, access, NDA limits.
- Referral sources and any per-period limits.
- Writing rules: punctuation, banned structures, words they hate, a locked positioning line if they have one.
- Claims they must never make, and numbers with the exact wording they can defend.

## Level calibration

Record the level-specific reading in the profile, not this generic text.

- **Junior (0 to 2 yrs):** the gate is environment. Design team and a senior to learn from. Sole-designer and "wear many hats" roles are high risk. Practice tier is valuable. Read responsibilities over titles.
- **Mid (2 to 5 yrs):** owns features end to end. Skip roles that are indefinite execution of others' specs. A Senior title at a small company is often accurate here.
- **Senior (5 to 8 yrs):** owns a product area; design is strategic. A defined problem to execute is a skip regardless of title. At large companies, Senior or untitled IC clears on its own. At small companies, Senior often means a level below worth; check what the role owns.
- **Staff+ (8+ yrs):** cross-team scope. Verify Staff is a real level and that the IC ladder continues above it. Founding-designer roles flip from risk to opportunity if equity and founders are real.

## Saving

Show the full draft profile, take corrections, save as `job-search-profile.md`. Tell the user to keep it in their Project so it loads every session.

## Revisiting

When the user overrides a criterion, ask once: one-time exception or profile change? If a change, edit the file and date it. A profile that drifts from the user's real criteria produces confident wrong screens.
