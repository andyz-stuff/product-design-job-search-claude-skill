# Intake

The goal is a filled-in profile in about ten minutes, not a complete picture of the user's career. Anything missing can be added the first time it matters.

## Ground rules

**Draft first, ask second.** Open by asking for a resume, LinkedIn URL, or portfolio. Most of the profile is derivable from a resume: level, years, domains, employer sizes, the reusable bullets. Draft those, then ask the user to correct. Correcting a draft takes a fraction of the effort of answering the same questions cold.

**Batch the questions.** Three or four rounds, several questions each. Do not ask one at a time. A designer who wanted a twenty-question form would have filled out a form.

**Push back once on vague answers, then move on.** "I'm flexible on comp" and "anywhere in the Bay Area is fine" are not usable. Push once with a concrete reframe. If the answer stays vague, write it down as vague and note that the screen will be soft on that step.

**Do not ask what the resume already answers.** Asking a designer how many years of experience they have after reading their resume signals you did not read it.

## Round 1: Level and target

Ask what you cannot infer:

- Current level, and target level. If those differ, what is the case for the jump?
- IC track only, or open to management? This one matters a lot and people are often unclear about it. If they are unsure, note it and revisit.
- Employed or searching after a layoff or departure? This sets urgency and changes tier weighting.
- Timeline. Immediate, or a slow look over six months?

## Round 2: Hard gates

These stop roles cold, so they need real numbers.

- **Comp floor, base.** If they do not have a number, help them derive one. Useful prompts: what are you making now, what is the number you would decline on a bad day, what does market data say for this level in this metro. Land on a single figure. A range here defeats the purpose.
- **Geography.** Get three lists: places that are a yes, places that are conditional and on what condition, places that are a no. "The Bay Area" is not one place for commute purposes, so push for specificity.
- **Days in office ceiling.** A number, not "hybrid is fine."
- **Relocation.** Yes, no, or for what.

## Round 3: Dealbreakers

People do not generate exclusions cold, so offer a menu and let them react. Read out common categories and ask which apply:

- Responsibilities they do not do: managing people, shipping production code, on-call, sales calls, being the only designer
- Disciplines that are not theirs: growth and conversion, data visualization and BI, geospatial, game UI, brand and marketing design, design systems as the whole job
- Industries they will not work in: defense, crypto, gambling, adtech, tobacco or vice, anything else
- Company shapes: pre-seed with no named investors, no equity, agencies and consultancies, staffing firms
- Posting signals: years asked above a threshold, unpaid design exercises, salary not disclosed

Then ask for anything specific to them that the menu missed, including individual companies or teams they will not consider and why. A warning from someone inside about a specific team is worth recording.

## Round 4: Domain and materials

- What kind of product problem do they want to be doing? Push past industry to shape of work: operational systems, consumer scale, developer tools, marketplaces, hardware-adjacent, whatever it is.
- What is in the portfolio, and is any of it under NDA or password-protected?
- Which domains do they have real evidence for, and which are true but only visible in older work? The second list is the soft-flag list.
- Any writing rules for their materials: punctuation preferences, structures they hate, house voice.

## Level calibration

Thresholds shift by level. Use this to interpret answers, and record the level-specific reading in the profile rather than the generic version.

**Junior, roughly 0 to 2 years.** The gate is environment, not scope. Is there a design team, is there someone senior to learn from, is the work real product design. Sole-designer roles and "wear many hats" postings are high risk here. Practice tier is genuinely valuable. Comp floors are metro-dependent and title inflation is rampant, so read responsibilities over titles.

**Mid, roughly 2 to 5 years.** Owns features end to end. Screen for whether the role is execution against someone else's specs indefinitely, and whether there is a path to owning a surface. A "Senior" title at a small company at this stage is often accurate rather than inflated.

**Senior, roughly 5 to 8 years.** Owns a product area, and design is treated as strategic. A role that hands over a defined problem to execute is a skip regardless of title. At a large company, a Senior or untitled IC posting is normal and clears the level step on its own. At a small company, a Senior title often signals scope a level below what they are worth, so look harder at what the role owns.

**Staff and principal, 8 or more years.** Scope crosses teams. The two things to verify: whether "Staff" is a real level or a senior job with a better title, and whether the IC ladder above them actually exists at that company. Sole-designer and founding-designer roles flip from risk to opportunity here, if the equity and the founder are real.

## Writing the profile

Draft the profile from the answers, show it to the user in full, and ask for corrections before saving. People catch errors in a draft they would never have volunteered in an interview.

Save as `job-search-profile.md` per `references/profile-schema.md`. Tell the user to keep it in their project so it loads automatically in future conversations, and that they can ask to change any criterion later and you will update the file.

Then give the workflow orientation described in Step 3 of SKILL.md.

## Revisiting

When the user overrides a profile criterion mid-conversation, ask whether this is a one-time exception or a change to the profile. Update the file if it is a change, with the date. A profile that silently drifts from the user's actual criteria is worse than no profile, because the screen keeps producing confident answers from stale inputs.
