# Resume system

One tailored resume per application, built from a master. Tailoring reorders and re-cuts. It never invents.

## Master content

Keep the master as `resume_master.json` (schema below) next to the profile. Every tailored build copies it and edits only what the posting needs. Never re-derive layout; edit content.

## Hard rules

- **Scope bullet first.** Each role's first bullet names the kind of work, no product names. It never moves. Tailoring reorders bullets below it.
- **Header title mirrors the posting,** floored at the profile's title floor and never bumped above the posting's level.
- **Locked positioning line stays fixed.** The rest of the summary can flex toward the posting.
- **Mirror nouns, never voice.** Match the posting's category nouns in Skills and bullet emphasis. Never echo its distinctive phrasing.
- **No keyword or metric the user cannot defend in an interview.** If it was never measured, describe the effect without a number.
- **Bullets about 2 to 3 lines.** Skills grouped into a few categories.
- **Drop low-signal blocks** (freelance, side projects) for large-company roles. Keep them for founding and 0-to-1 roles.
- **North America norms:** no photo, birth date, marital status, or full street address. City and state/province is enough. Letter size.

## Length by level

- Junior and mid: one page. The portfolio carries the case.
- Senior and above: one page preferred, two acceptable. Scope and outcomes carry the resume.
- Over the limit: trim in the profile's trim order. Default: Skills, then oldest or weakest role, then low-signal lines in recent roles.

## Draft step

Show only the diff from the master: new title, summary change, reordered or swapped bullets, Skills variant. One line on why each change serves this posting. Wait for approval.

## Build

```bash
python3 scripts/resume_builder.py content.json out.pdf [max_pages]
```

Prints `OK` or a list of issues. Fix and rebuild; never ship a known defect with a note.

The script: self-installs Inter (Helvetica fallback if offline), auto-fits by compressing spacing before shrinking type, keeps each role's header with its first bullet, and validates the text layer.

### content.json

```json
{
  "name": "First Last",
  "title": "Posting title, mirrored",
  "contact": ["portfolio.com", "email@example.com", "linkedin.com/in/handle", "City, ST"],
  "summary": "…",
  "experience": [
    {"role": "…", "company": "…", "meta": ["Mon YYYY – Mon YYYY", "City, ST"],
     "bullets": ["scope bullet first", "…"]}
  ],
  "education": ["Degree, School"],
  "skills": [["Category", "item, item, item"]],
  "rules": {
    "curly_quotes": true,
    "banned_chars": ["—"],
    "banned_phrases": ["phrase from profile", "\\bregex\\b"]
  }
}
```

Content is ReportLab markup: escape `&` as `&amp;`. Type curly quotes directly if the profile requires them. `banned_phrases` are regex, matched case-insensitive with line wraps collapsed. Use `\b` word boundaries for short terms to avoid substring false positives.

## Verify before delivery

The script checks page count, banned characters, and banned phrases. If the layout changed, also render page 1 to an image and look at it:

```bash
python3 -c "import pypdfium2 as p; p.PdfDocument('out.pdf')[0].render(scale=1.6).to_pil().save('p1.png')"
```
