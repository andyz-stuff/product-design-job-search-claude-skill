# Resume system

One tailored resume per application, built from a master. Tailoring means reordering and re-cutting. It never means inventing.

## Hard rules

- **Scope bullet first.** Every role's first bullet says what kind of work was done, no product names. It never moves. Per-posting swaps only reorder the bullets below it. This gives a recruiter the shape of each role in one line, and it keeps tailoring from producing a different document every time.
- **Header title mirrors the posting.** Use the posting's exact title, with the user's target level as the floor. Do not bump a level above it.
- **Mirror their nouns, never their voice.** Keyword-match on category nouns so the posting's language is present. Never echo the posting's distinctive phrasing or sentence structure. A resume that sounds like the JD reads as pandering.
- **Never insert a keyword the user cannot defend in an interview,** including for ATS coverage. An interview that exposes a padded keyword costs more than the screen it passed.
- **No metrics the user cannot back.** If a number was never measured, describe the effect without a number.
- **No bullet count limit.** Let content set the length.
- **Drop low-signal blocks** for large-company applications. Freelance and side-project sections read as noise there. Keep them for founding and 0-to-1 roles.
- **Verify the text layer on every page** before shipping. A page that is not machine-readable is a page the ATS did not see.

## By level

- **Junior and mid:** the portfolio does more work than the resume. Keep the resume to one page and spend the effort on making the case studies match the role. Craft and process evidence matter more than scope claims.
- **Senior and above:** scope claims carry the resume. Lead with what was owned and what changed, not what was produced. Two pages is fine.

## Voice

Flat, plain, punchy. Cut any sentence that notices itself. Avoid negation-contrast constructions. Claims must be defensible.

Check the profile's writing rules and enforce them mechanically before delivery.

## Skills block

Re-cut per posting. Keep a few pre-built variants for the recurring role archetypes in the search so this is not rewritten from scratch each time. Group by category rather than listing flat.

## PDF build

Python with ReportLab works well: exact control over the contact line, page breaks, and font embedding, and reproducible across builds. Alternatives are fine, but whatever produces the file has to be re-runnable, because the resume gets rebuilt dozens of times.

Two things that break most often:

- **Contact line wrapping.** Drop the contact style a point or two and use non-breaking spaces inside location strings so the state never orphans to the next line.
- **Orphaned role headers.** Wrap each role's header, meta line, and first bullet in a keep-together block so a job heading never strands at the bottom of a page.

## Verification before delivery

Run all of these. Do not deliver on the assumption the build was clean.

- Page count.
- Text extraction on every page, then read the output. Confirm the last page has real text.
- Search for characters banned by the profile's writing rules.
- Render pages to images and look at them if the layout changed at all.

Fix and rebuild rather than shipping with a known defect and a note about it.
