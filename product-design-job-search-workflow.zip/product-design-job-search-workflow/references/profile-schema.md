# Profile schema

The structure to write `job-search-profile.md` in. Fill from intake. Leave a section out rather than filling it with a guess, and note in the file which sections are thin.

Every criterion that came from a vague answer gets marked, so the screen can flag when it is leaning on a soft input.

```markdown
# Job Search Profile
*Last updated: [date]*

## Level and target
- Current level and years:
- Target level:
- Title targets by company size: small / mid / large
- IC track only, or open to management:
- Situation: employed, searching after departure, timeline
- Downlevel decision, if made, with date and reasoning

## Hard gates
- Comp floor, base: [single number]
- Geography, yes:
- Geography, conditional, and on what condition:
- Geography, no:
- Days in office ceiling:
- Relocation:
- Ownership requirement: [level-specific, see intake calibration]

## Hard exclusions
Testable statements, not vibes. Any hit is an automatic skip.
- [responsibilities]
- [disciplines]
- [industries]
- [company shapes]
- [posting signals]
- [named companies or teams, with reason]

## Soft flags
Weighed, never auto-skip. For each, how to handle it.
- [flag]: [handling]

## Durability test
If the technology currently hyped in this field stopped advancing today, does this company's customer problem still exist at the same size? Note category exceptions.

## Tiers
- Dream:
- Sweet spot:
- Safety net:
- Practice: [active, or dropped with date]

## Positioning
- One line on the shape of my work, not the industry:
- Secondary hook, if there is one:
- What I want to be doing:

## Standing content
Per role, the accurate reusable framings. This is the raw material for every tailored resume.
- [Role, dates, team, scope line]
  - Reusable bullets:
  - Numbers I can defend in an interview:
  - Numbers I must never claim:

## Portfolio
- URL and access:
- Case studies and what each one demonstrates:
- Anything under NDA:

## Locked application answers
Long-form answers to recurring questions, written once and adapted.
- [question]: [answer]

## Writing rules
- Punctuation:
- Structures to avoid:
- Voice:
- Vocabulary the target industry uses:
```
