# Profile schema

Write `job-search-profile.md` in this structure. Omit a section rather than guess. Mark criteria from vague answers with `(soft)`. Keep lines short; this file loads every session.

```markdown
# Job Search Profile
*Last updated: YYYY-MM-DD*

## Level and target
- Current level, years:
- Target level:
- Title targets by company size: small / mid / large
- IC only or open to management:
- Situation and timeline:
- Needs sponsorship: yes / no
- Downlevel decision (date, reasoning):

## Hard gates
- Base floor: [one number, currency]
- Geography yes:
- Geography conditional (condition):
- Geography no:
- Days-in-office ceiling:
- Relocation:
- Ownership reading for my level:

## Hard exclusions
Testable statements. Any hit is a skip.
-

## Soft flags
- [flag]: [handling]

## Target domains
-

## Tiers
- Dream:
- Sweet spot:
- Safety net:
- Practice: active | dropped YYYY-MM-DD

## Passes (do not resurface)
- [company or team]: [reason, date]

## Referrals
- [company]: [source, limit if any]

## Positioning
- Locked positioning line (never reworded per JD):
- Secondary hook:

## Standing content
Per role. Raw material for every tailored resume.
- [Role · Company · dates · scope line]
  - Bullets:
  - Defensible numbers (exact wording):
  - Never claim:

## Resume settings
- Page limit:
- Header title floor:
- Trim order when over length:
- Skills variants by role archetype:

## Portfolio
- URL and access:
- Case studies and what each proves:
- NDA limits:

## Locked answers
- [recurring question]: [answer]

## Writing rules
- Punctuation:
- Banned structures:
- Banned phrases (also fed to the build validator):
- Voice:
```
