# Tracker

One markdown file: `job-tracker-YYYY-MM-DD.md`. New date in the filename each session it changes.

## Format

```markdown
# Job Tracker
*Last updated: YYYY-MM-DD*

## In progress
| Company | Role | Tier | Applied | Last update | Status | Next |
|---|---|---|---|---|---|---|

## Active
| Company | Role | Tier | Applied | Last update | Status | Next |
|---|---|---|---|---|---|---|

## Closed
| Company | Role | Tier | Applied | Last update | Outcome |
|---|---|---|---|---|---|
```

- **In progress:** any live conversation (recruiter screen onward). Always at the top.
- **Active:** applied, no response yet.
- **Closed:** rejected, withdrawn, passed, offer declined.
- Each pile sorted by last update, newest first.

## Edit rules

- Change rows by exact-text string replacement. Insert new rows after a known anchor row (the table header). Never use line numbers. Never regenerate the file.
- Update the `Last updated` date in the same edit.
- Moving a row between piles: delete by exact text, insert under the target pile's header.
- After editing, reply with one line per changed row. No full table unless asked.
- Update when the user reports something. Do not prompt them for updates.
